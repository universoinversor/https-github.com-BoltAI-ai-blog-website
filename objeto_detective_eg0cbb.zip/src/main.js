// Código JavaScript para detectar objetos
    const tf = require('@tensorflow/tfjs');
    const cv = require('opencv4nodejs');

    // Cargar modelo de detección de objetos
    const model = await tf.loadLayersModel('https://example.com/model.json');

    // Obtener imagen desde la cámara web
    const video = document.getElementById('video');
    const canvas = document.getElementById('canvas');
    const ctx = canvas.getContext('2d');

    // Detectar objetos en la imagen
    function detectObjects() {
      const img = cv.imread(video);
      const gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY);
      const thresh = cv.threshold(gray, 0, 255, cv.THRESH_BINARY_INV + cv.THRESH_OTSU);

      const objects = model.predict(thresh);
      console.log(objects);
    }

    // Actualizar la aplicación cada segundo
    setInterval(detectObjects, 1000);
